<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Admin</title>
    <link rel="stylesheet" href="../../css/admin.css">
</head>
<body>
        <header>
            <h1 class="letraHeader">Admin</h1>
                <nav id="aveces">
                    <ul>
                        <li><a href="#">Dashboard</a>
                            <ul style="--cantidad-items: 2">
                                <li><a href="estadisticas.php">Estadisticas</a></li>
                                <li><a href="maquinasAlmacenadas.php">MaquinasPorAlmacen</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Maquinaria</a>
                    <ul style="--cantidad-items: 5">
                    <li><a href="categoria.php">Categorias</a></li>
                        <li><a href="dispo.php">Disponibilidad</a></li>
                        <li><a href="mantenimiento.php">Mantenimiento</a></li>
                        <li><a href="agregarm.php">Agregar maquina</a></li>
                        <li><a href="agregarmarca.php">Agregar marca</a></li>
                        <li><a href="agregarmodelo.php">Agregar modelo</a></li>
                    </ul>
                </li>
                <li id="reservas"><a href="#">Reservas</a>
                    <ul style="--cantidad-items: 3">
                        <li><a href="confirmacion.php">Confirmacion</a></li>
                        <li><a href="maquinasReservadas.php">MaquinasReservadas</a></li>
                        <li><a href="reservasRep.php">ReservasDeRepresentantes</a></li>
                    </ul>
                </li>
                <li><a href="#">Choferes</a>
                    <ul style="--cantidad-items: 1">
                        <li><a href="agregarch.php">Agregar Choferes</a></li>
                    </ul>
                    <li><a href="../../app/login.php">Logout</a>
                    </ul>
                </nav>
                <div class="login-logout-buttons">
                
            </div>
        </header>        
   
</body>
</html>

<?php require '../../data/conexionDB.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/admin.css">
    <script defer src="popModal.js"></script>
</head>

<body>
    
    <header>
    <h1 class="letraHeader">Admin</h1>
        <nav id="aveces">
            <ul>
            <li><a href="#">Dashboard</a>
                            <ul style="--cantidad-items: 2">
                                <li><a href="estadisticas.php">Estadisticas</a></li>
                                <li><a href="maquinasAlmacenadas.php">MaquinasPorAlmacen</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Maquinaria</a>
                    <ul style="--cantidad-items: 5">
                    <li><a href="categoria.php">Categorias</a></li>
                        <li><a href="dispo.php">Disponibilidad</a></li>
                        <li><a href="mantenimiento.php">Mantenimiento</a></li>
                        <li><a href="agregarm.php">Agregar maquina</a></li>
                        <li><a href="agregarmarca.php">Agregar marca</a></li>
                        <li><a href="agregarmodelo.php">Agregar modelo</a></li>
                    </ul>
                </li>
                <li id="reservas"><a href="#">Reservas</a>
                    <ul style="--cantidad-items: 3">
                        <li><a href="confirmacion.php">Confirmacion</a></li>
                        <li><a href="maquinasReservadas.php">MaquinasReservadas</a></li>
                        <li><a href="reservasRep.php">ReservasDeRepresentantes</a></li>
                    </ul>
                </li>
                <li><a href="#">Choferes</a>
                    <ul style="--cantidad-items: 1">
                        <li><a href="agregarch.php">Agregar Choferes</a></li>
                    </ul>
                    <li><a href="../../app/login.php">Logout</a>
            </ul>
        </nav>
        <ul class="navbar-nav">
            <?php if (!empty($_SESSION["id"])): ?>
              <!-- Si el usuario está autenticado, muestra su nombre y opción de logout -->
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false">
                  Bienvenido(a), <?php echo $_SESSION["id"]; ?>
                  <?php
                    include_once '../../data/conexionDB.php';
                    $dataset = mysqli_query($conn,"select codigo FROM clientes WHERE usuario = '".$_SESSION["id"]."';");
                    while ($registro = mysqli_fetch_assoc($dataset)) {
                      $clCod = $registro['codigo'];
                    } 
                  ?>
                
                </a>
                <div class="dropdown-menu">
                <a class="dropdown-item" href="historial.php">Historial</a>
                  <a class="dropdown-item" href="seguimiento.php">Seguimiento</a>
                  <a class="dropdown-item" href="idxAdeudos.php">Adeudos</a>
                  <a class="dropdown-item" href="../../app/logout.php">Logout</a>
                </div>
              </li>
            <?php else: ?>
             
              <li class="nav-item">
                <a class="nav-link" href="../../app/login.php"></a>
              </li>
            <?php endif; ?>
    </header>
    <main>
        <h1>Categoria de las maquinas</h1>
        <div class = "flex-container">
            <div class = "container" style = "margin:0;">
            <br>
            <br>
            <div class = "row">
            <table class = "table">
              <tr class = "table-dark">
                  <td>Codigo</td>
                  <td>Nombre</td>
                  <td>Limite de carga</td>
                  <td></td>
                  
                 
              </tr>
    
              <?php
              $i = 1;
              
    
              $query = "select * from categorias";
              $rows = mysqli_query($conn, $query);
    
              ?>
              <?php foreach($rows as $row) : ?>
              <tr>
                <td><?php echo $row["codigo"]; ?></td>
                <td><?php echo $row["nombre"]; ?></td>
                <td><?php echo $row["limiteCarga"]; ?></td>
    
               
    
                <td><a href = "../../app/deletemaquina.php?id=<?php echo $row["codigo"]; ?> "><img src = "../../images/trash3-fill.svg" style="padding-bottom:3px" class = "trashcan filter-red" ></a></td>
              
                <!--<td><img src = "img/<?php echo $row['imagen'];?>" width = 200 alt = ""></td> -->
    
              </tr>
              
              <?php endforeach; ?>
    
              </table>
              </div>
              </div>
              </div>
              <br>
    </main>
</body>
</html>


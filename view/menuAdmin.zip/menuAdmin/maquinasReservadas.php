<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maquinas Reservadas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/admin.css">
    <script defer src="popModal.js"></script>
</head>
<body>
    <header>
        <h1 class="letraHeader">Admin</h1>
        <nav id="aveces">
            <ul>
                <li><a href="#">Dashboard</a>
                    <ul style="--cantidad-items: 2">
                        <li><a href="estadisticas.php">Estadisticas</a></li>
                        <li><a href="maquinasAlmacenadas.php">MaquinasPorAlmacen</a></li>
                    </ul>
                </li>
                <li><a href="#">Maquinaria</a>
                    <ul style="--cantidad-items: 5">
                    <li><a href="categoria.php">Categorias</a></li>
                        <li><a href="dispo.php">Disponibilidad</a></li>
                        <li><a href="mantenimiento.php">Mantenimiento</a></li>
                        <li><a href="agregarm.php">Agregar maquina</a></li>
                        <li><a href="agregarmarca.php">Agregar marca</a></li>
                        <li><a href="agregarmodelo.php">Agregar modelo</a></li>
                    </ul>
                </li>
                <li id="reservas"><a href="#">Reservas</a>
                    <ul style="--cantidad-items: 3">
                        <li><a href="confirmacion.php">Confirmacion</a></li>
                        <li><a href="maquinasReservadas.php">MaquinasReservadas</a></li>
                        <li><a href="reservasRep.php">ReservasDeRepresentantes</a></li>
                    </ul>
                </li>
                <li><a href="#">Choferes</a>
                    <ul style="--cantidad-items: 1">
                        <li><a href="agregarch.php">Agregar Choferes</a></li>
                    </ul>
                </li>
                <li><a href="../../app/login.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <?php
        include '../../data/conexionDB.php';

        $conexionDB = new conexionDB();

        if (!$conexionDB->connect()) {
            die("Error de conexión: " . mysqli_connect_error());
        }

        // Verificar si se ha enviado el formulario
        if (isset($_POST['codigoCliente'])) {
            $codigoClienteSeleccionado = $_POST['codigoCliente'];

            // Obtener las máquinas reservadas del cliente seleccionado
            $query = "SELECT
                        r.folio AS 'Folio de la reserva',
                        CONCAT(c.nombre, ' ', c.apPat, ' ', COALESCE(c.apMat, '')) AS 'Nombre completo del cliente',
                        ma.numSerie AS 'Número de serie de la máquina',
                        mc.nombre AS 'Nombre de la marca',
                        modelo.nombre AS 'Nombre del modelo',
                        modelo.categoria AS 'Categoría del modelo',
                        modelo.anoFabricacion AS 'Año',
                        rm.cantDias AS 'Días de reserva de la máquina',
                        (rm.cantDias * ma.precioDia) AS 'ImporteRenta'
                    FROM
                        re_maq rm
                    JOIN reservas r ON rm.reserva = r.folio
                    JOIN maquinas ma ON rm.maquina = ma.codigo
                    JOIN modelos modelo ON ma.modelo = modelo.num
                    JOIN marcas mc ON modelo.marca = mc.codigo
                    JOIN clientes c ON r.cliente = c.codigo
                    WHERE c.codigo = $codigoClienteSeleccionado";

            $result = $conexionDB->execquery($query);

            // Mostrar las máquinas reservadas
            echo "<h2>Maquinas del Cliente $codigoClienteSeleccionado</h2>";
            echo "<div class='flex-container'>";
            echo "<div class='container' style='margin:0;'>";
            echo "<br><br>";
            echo "<div class='row'>";
            echo "<table class='table'>";
            echo "<tr class='table-dark'>";
            echo "<td>Folio de la Reserva</td>";
            echo "<td>Nombre del Cliente</td>";
            echo "<td>Número de serie de la máquina</td>";
            echo "<td>Nombre de la Marca</td>";
            echo "<td>Nombre del Modelo</td>";
            echo "<td>Categoría del Modelo</td>";
            echo "<td>Año</td>";
            echo "<td>Días de Reserva</td>";
            echo "<td>Importe de Renta</td>";
            echo "</tr>";

            while ($maquina = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>{$maquina['Folio de la reserva']}</td>";
                echo "<td>{$maquina['Nombre completo del cliente']}</td>";
                echo "<td>{$maquina['Número de serie de la máquina']}</td>";
                echo "<td>{$maquina['Nombre de la marca']}</td>";
                echo "<td>{$maquina['Nombre del modelo']}</td>";
                echo "<td>{$maquina['Categoría del modelo']}</td>";
                echo "<td>{$maquina['Año']}</td>";
                echo "<td>{$maquina['Días de reserva de la máquina']}</td>";
                echo "<td>{$maquina['ImporteRenta']}</td>";
                echo "</tr>";
            }

            echo "</table>";
            echo "</div>";

            // Botón para volver a la selección del cliente
            echo "<form method='post' action='maquinasReservadas.php'>";
            echo "<input type='submit' class='btn btn-primary' value='Volver a la Selección del Cliente'>";
            echo "</form>";

            echo "</div>";
            echo "</div>";
            echo "<br>";
        } else {
            // Si no se ha enviado el formulario, mostrar el formulario de selección
            $queryClientes = "SELECT codigo, CONCAT(nombre, ' ', apPat, ' ', COALESCE(apMat, '')) AS nombreCompleto FROM clientes";
            $resultClientes = $conexionDB->execquery($queryClientes);

            $clientes = array();

            // Obtener los datos de los clientes
            while ($row = mysqli_fetch_assoc($resultClientes)) {
                $clientes[] = $row;
            }

            echo "<h2>Selecciona un cliente:</h2>";
            echo "<form method='post' action='maquinasReservadas.php'>";
            echo "<select name='codigoCliente' class='form-select'>";
            foreach ($clientes as $cliente) {
                echo "<option value='{$cliente['codigo']}'>{$cliente['nombreCompleto']}</option>";
            }
            echo "</select>";
            echo "<input type='submit' class='btn btn-primary' value='Mostrar Maquinas Reservadas'>";
            echo "</form>";
        }
        ?>
    </main>
</body>
</html>

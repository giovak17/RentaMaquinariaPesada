<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/admin.css">
    <script defer src="popModal.js"></script>
</head>
<body>
    
    <header>
    <h1 class="letraHeader">Admin</h1>
        <nav id="aveces">
            <ul>
            <li><a href="#">Dashboard</a>
                            <ul style="--cantidad-items: 2">
                                <li><a href="estadisticas.php">Estadisticas</a></li>
                                <li><a href="maquinasAlmacenadas.php">MaquinasPorAlmacen</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Maquinaria</a>
                    <ul style="--cantidad-items: 5">
                    <li><a href="categoria.php">Categorias</a></li>
                        <li><a href="dispo.php">Disponibilidad</a></li>
                        <li><a href="mantenimiento.php">Mantenimiento</a></li>
                        <li><a href="agregarm.php">Agregar maquina</a></li>
                        <li><a href="agregarmarca.php">Agregar marca</a></li>
                        <li><a href="agregarmodelo.php">Agregar modelo</a></li>
                    </ul>
                </li>
                <li id="reservas"><a href="#">Reservas</a>
                    <ul style="--cantidad-items: 3">
                        <li><a href="confirmacion.php">Confirmacion</a></li>
                        <li><a href="maquinasReservadas.php">MaquinasReservadas</a></li>
                        <li><a href="reservasRep.php">ReservasDeRepresentantes</a></li>
                    </ul>
                </li>
                <li><a href="#">Choferes</a>
                    <ul style="--cantidad-items: 1">
                        <li><a href="agregarch.php">Agregar Choferes</a></li>
                    </ul>
                    <li><a href="../../app/login.php">Logout</a>
            </ul>
        </nav>
    </header>
    <main>
    <strong> Agregar modelos</strong>

    <a href="agregarmodelo2.php">
    <button class = "boton">+</button>
    </a>
    <div class = "flex-container">
    <div class = "container">
    <br>
    <br>
    <div class = "row">   
    <table class="table">
            <tr class = "table-dark" >
              <td>Numero de modelo</td>
              <td>Año de fabricacion</td>
              <td>Capacidad de carga</td>
              <td>Nombre del modelo</td>
              <td>Descripcion</td>
              <td>Foto</td>
              <td>Precio por dia</td>
              <td>Marca</td>
              <td></td>
              <td></td>
          </tr>
        
          <?php
          include('../../data/modelos.php');
          $miModelos = new modelos();
          $dataset = $miModelos->getAllModelos();
          if($dataset != 'wrong'){
            while($registro = mysqli_fetch_assoc($dataset)){
                echo "<tr>";  
                echo "<td>".$registro['num']."</td>";
           
                echo "<td>".$registro['anoFabricacion']."</td>";
            
                echo "<td>".$registro['capacidadCarga']."</td>";
             
                echo "<td>".$registro['nombre']."</td>";
              
                echo "<td>".$registro['descripcion']."</td>";
               
                echo "<td>".$registro['imagen']."</td>";
              
                //echo "<td>".$registro['precioDia']."</td>";
            
                echo "<td>".$registro['marca']."</td>";
                echo '<td><a href = "#"><img src = "../../images/trash3-fill.svg" style="padding-bottom:3px" class = "trashcan filter-red" ></a></td>';
                echo '<td><a href = "updateMaquina.php?"><img src = "../../images/pencil-fill.svg" style="padding-bottom:3px" class = "pencil filter-yellow"></a></td>';
                echo "</tr>";

              
            }
        }else{
                echo "No hay datos que consultar";
            }
          
          ?>
          </table>
        </div>
        </div>
        </div>
            <!--<button class="btnOpen">Open</button>--> 
      
    </main>
    <div>
        
    </div>
    
</body>
</html>

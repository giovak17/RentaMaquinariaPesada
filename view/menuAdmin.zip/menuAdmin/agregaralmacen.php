<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Admin</title>
    <link rel="stylesheet" href="../../css/admin.css">
    <script defer src="popModal.js"></script>
</head>
<body>
    
    <header>
    <h1 class="letraHeader">Admin</h1>
        <nav id="aveces">
            <ul>
                <li><a href="#">Dashboard</a>
                    <ul style="--cantidad-items: 1">
                        <li><a href="estadisticas.php">Estadisticas</a></li>
                    </ul>
                </li>
                <li><a href="#">Maquinaria</a>
                    <ul style="--cantidad-items: 5">
                    <li><a href="categoria.php">Categorias</a></li>
                        <li><a href="dispo.php">Disponibilidad</a></li>
                        <li><a href="mantenimiento.php">Mantenimiento</a></li>
                        <li><a href="agregarm.php">Agregar maquina</a></li>
                        <li><a href="agregarmarca.php">Agregar marca</a></li>
                        <li><a href="agregarmodelo.php">Agregar modelo</a></li>
                    </ul>
                </li>
                <li id="reservas"><a href="#">Reservas</a>
                    <ul style="--cantidad-items: 2">
                        <li><a href="confirmacion.php">Confirmacion</a></li>
                        <li><a href="maquinasReservadas.php">MaquinasReservadas</a></li>
                    </ul>
                </li>
                <li><a href="#">Choferes</a>
                    <ul style="--cantidad-items: 1">
                        <li><a href="agregarch.php">Agregar Choferes</a></li>
                    </ul>
                    <li><a href="../../app/login.php">Logout</a>  
            </ul>
        </nav>
    </header>
    <main>
        <h1>Agregar almacen</h1> 
        <section>
 
        <form method="post" action="../../app/addAlmacenes.php" enctype="multipart/form-data">
        <br>
    <label>Codigo</label> <input type="text" name="txtCodigo" required>
    <br>
    <label>Nombre</label> <input type="text" name="txtNombre" required>
    <br>
    <label>Número de Teléfono</label> <input type="text" name="txtNumTel" required>
    <br>
    <label>Colonia</label> <input type="text" name="txtColonia" required>
    <br>
    <label>Número</label> <input type="number" name="Num" required>
    <br>
    <label>Calle</label> <input type="text" name="txtCalle" required>
    <br>
    <label>Ciudad</label>
    <select name="txtCiudad" class="listDeploy" required>
        <option value="" selected disabled>-- Seleccione una ciudad</option>
        <?php
        include('../../data/ciudades.php');
        $miCiudades = new ciudades();
        $dataSet = $miCiudades->getAllCiudades();

        if ($dataSet != 'wrong') {
            while ($rs = mysqli_fetch_assoc($dataSet)) {
                echo $rs['codigo'];
                echo 'hola';
        ?>
     <option value="<?php echo $rs['codigo']; ?>"><?php echo $rs['nombre']; ?></option>
           
        <?php
            }
        } else {
            echo "Error al recuperar datos";
        }
        ?>
    </select>
    <br><br>
    <button type="submit">Enviar</button><button type="reset">Reset</button>
</form>

    </main>
    <div>
        
    </div>
    
</body>
</html>


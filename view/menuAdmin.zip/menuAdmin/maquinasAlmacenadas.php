<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maquinas Por Almacen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/admin.css">
    <script defer src="popModal.js"></script>
</head>
<body>
    <header>
        <h1 class="letraHeader">Admin</h1>
        <nav id="aveces">
            <ul>
                <li><a href="#">Dashboard</a>
                    <ul style="--cantidad-items: 2">
                        <li><a href="estadisticas.php">Estadisticas</a></li>
                        <li><a href="maquinasAlmacenadas.php">MaquinasPorAlmacen</a></li>
                    </ul>
                </li>
                <li><a href="#">Maquinaria</a>
                    <ul style="--cantidad-items: 5">
                    <li><a href="categoria.php">Categorias</a></li>
                        <li><a href="dispo.php">Disponibilidad</a></li>
                        <li><a href="mantenimiento.php">Mantenimiento</a></li>
                        <li><a href="agregarm.php">Agregar maquina</a></li>
                        <li><a href="agregarmarca.php">Agregar marca</a></li>
                        <li><a href="agregarmodelo.php">Agregar modelo</a></li>
                    </ul>
                </li>
                <li id="reservas"><a href="#">Reservas</a>
                    <ul style="--cantidad-items: 3">
                        <li><a href="confirmacion.php">Confirmacion</a></li>
                        <li><a href="maquinasReservadas.php">MaquinasReservadas</a></li>
                        <li><a href="reservasRep.php">ReservasDeRepresentantes</a></li>
                    </ul>
                </li>
                <li><a href="#">Choferes</a>
                    <ul style="--cantidad-items: 1">
                        <li><a href="agregarch.php">Agregar Choferes</a></li>
                    </ul>
                </li>
                <li><a href="../../app/login.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <?php
        include '../../data/conexionDB.php';

        $conexionDB = new conexionDB();

        if (!$conexionDB->connect()) {
            die("Error de conexión: " . mysqli_connect_error());
        }

        // Verificar si se ha enviado el formulario
        if (isset($_POST['codigoAlmacen'])) {
            $codigoAlmacenSeleccionado = $_POST['codigoAlmacen'];

            // Obtener las máquinas en el almacén seleccionado
            $query = "SELECT al.ciudad AS 'Nombre de la ciudad', 
                            al.nombre AS 'Nombre del almacén', 
                            al.calle AS 'Dirección del almacén', 
                            ma.numSerie AS 'Número de serie de la máquina', 
                            mc.nombre AS 'Nombre de la marca',
                            modl.nombre AS 'Nombre del modelo', 
                            cat.nombre AS 'Categoría del modelo', 
                            modl.anoFabricacion AS 'Año' 
                    FROM almacenes al 
                    JOIN maquinas ma ON al.codigo = ma.almacen 
                    JOIN modelos modl ON ma.modelo = modl.num 
                    JOIN marcas mc ON modl.marca = mc.codigo 
                    JOIN categorias cat ON modl.categoria = cat.codigo
                    WHERE al.codigo = '$codigoAlmacenSeleccionado'";

            $result = $conexionDB->execquery($query);

            // Mostrar las máquinas en el almacén
            echo "<h2>Máquinas en el Almacén $codigoAlmacenSeleccionado</h2>";
            echo "<div class='flex-container'>";
            echo "<div class='container' style='margin:0;'>";
            echo "<br><br>";
            echo "<div class='row'>";
            echo "<table class='table'>";
            echo "<tr class='table-dark'>";
            echo "<td>Nombre de la ciudad</td>";
            echo "<td>Nombre del almacén</td>";
            echo "<td>Dirección del almacén</td>";
            echo "<td>Número de serie de la máquina</td>";
            echo "<td>Nombre de la marca</td>";
            echo "<td>Nombre del modelo</td>";
            echo "<td>Categoría del modelo</td>";
            echo "<td>Año</td>";
            echo "</tr>";

            while ($maquina = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>{$maquina['Nombre de la ciudad']}</td>";
                echo "<td>{$maquina['Nombre del almacén']}</td>";
                echo "<td>{$maquina['Dirección del almacén']}</td>";
                echo "<td>{$maquina['Número de serie de la máquina']}</td>";
                echo "<td>{$maquina['Nombre de la marca']}</td>";
                echo "<td>{$maquina['Nombre del modelo']}</td>";
                echo "<td>{$maquina['Categoría del modelo']}</td>";
                echo "<td>{$maquina['Año']}</td>";
                echo "</tr>";
            }

            echo "</table>";
            echo "</div>";

            // Botón para volver a la selección del almacén
            echo "<form method='post' action='maquinasAlmacenadas.php'>";
            echo "<button type='submit' class='btn btn-primary'>Volver a la Selección del Almacén</button>";
            echo "</form>";

            echo "</div>";
            echo "</div>";
            echo "<br>";
        } else {
            // Si no se ha enviado el formulario, mostrar el formulario de selección
            $queryAlmacenes = "SELECT codigo, nombre FROM almacenes";
            $resultAlmacenes = $conexionDB->execquery($queryAlmacenes);

            $almacenes = array();

            // Obtener los datos de los almacenes
            while ($row = mysqli_fetch_assoc($resultAlmacenes)) {
                $almacenes[] = $row;
            }

            echo "<h2>Selecciona un almacén:</h2>";
            echo "<form method='post' action='maquinasAlmacenadas.php'>";
            echo "<select name='codigoAlmacen' class='form-select'>";
            foreach ($almacenes as $almacen) {
                echo "<option value='{$almacen['codigo']}'>{$almacen['nombre']}</option>";
            }
            echo "</select>";
            echo "<button type='submit' class='btn btn-primary'>Mostrar Máquinas en el Almacén</button>";
            echo "</form>";
        }
        ?>
    </main>
</body>
</html>

<?php require '../../data/conexionDB.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/admin.css">
    <script defer src="popModal.js"></script>
</head>
<body>
    
    <header>
    <h1 class="letraHeader">Admin</h1>
        <nav id="aveces">
            <ul>
            <li><a href="#">Dashboard</a>
                            <ul style="--cantidad-items: 2">
                                <li><a href="estadisticas.php">Estadisticas</a></li>
                                <li><a href="maquinasAlmacenadas.php">MaquinasPorAlmacen</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Maquinaria</a>
                    <ul style="--cantidad-items: 5">
                    <li><a href="categoria.php">Categorias</a></li>
                        <li><a href="dispo.php">Disponibilidad</a></li>
                        <li><a href="mantenimiento.php">Mantenimiento</a></li>
                        <li><a href="agregarm.php">Agregar maquina</a></li>
                        <li><a href="agregarmarca.php">Agregar marca</a></li>
                        <li><a href="agregarmodelo.php">Agregar modelo</a></li>
                    </ul>
                </li>
                <li id="reservas"><a href="#">Reservas</a>
                    <ul style="--cantidad-items: 3">
                        <li><a href="confirmacion.php">Confirmacion</a></li>
                        <li><a href="maquinasReservadas.php">MaquinasReservadas</a></li>
                        <li><a href="reservasRep.php">ReservasDeRepresentantes</a></li>
                    </ul>
                </li>
                <li><a href="#">Choferes</a>
                    <ul style="--cantidad-items: 1">
                        <li><a href="agregarch.php">Agregar Choferes</a></li>
                    </ul>
                    <li><a href="../../app/login.php">Logout</a>
            </ul>
        </nav>
    </header>
    <main>
        <h1>Estadisticas</h1>
        <h4>- Cantidad de clientes</h4>
        <h4>- Cantidad de resevas</h4>
        <h4>- Maquinas rentadas</h4>
        <div class = "flex-container">
            <div class = "container" style = "margin:0;">
            <br>
            <br>
            <div class = "row">
            <table class="table table-sm">

    
              <?php
              $i = 1;
              
    
              $query = "select 
              count(cli.codigo) as Clientes
              from clientes as cli ";
              
              $rows = mysqli_query($conn, $query);

              $query1 = " select 
              count(rv.folio) as Reservas
              from reservas as rv";
              $rows1 = mysqli_query($conn, $query1);

              $query2 = "select
              count(codigo) as CantMaquinasReservadas
              from maquinas
              where estatusM = 'RES'";
              $rows2 = mysqli_query($conn, $query2);
    
              ?>

              <?php foreach($rows as $row) : ?>
              <tr>
                <td> Cantidad de Clientes </td>
                <td><?php echo $row["Clientes"]; ?></td>
    
              </tr>
              
              <?php endforeach; ?>

              <?php foreach($rows1 as $row) : ?>
              <tr>
                <td> Cantidad de Reservas </td> 
                <td><?php echo $row["Reservas"]; ?></td>
    
              </tr>
              
              <?php endforeach; ?>

              <?php foreach($rows2 as $row) : ?>
              <tr>
                <td> Total de Maquinas reservadas </td>
                <td><?php echo $row["CantMaquinasReservadas"]; ?></td>
    
              </tr>
              
              <?php endforeach; ?>
    
              </table>
              </div>
              </div>
              </div>
              <br>
    </main>
  </body>
</html>